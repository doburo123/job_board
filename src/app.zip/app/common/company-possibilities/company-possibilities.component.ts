import { Component } from '@angular/core';

@Component({
    selector: 'app-company-possibilities',
    imports: [],
    templateUrl: './company-possibilities.component.html',
    styleUrl: './company-possibilities.component.scss'
})
export class CompanyPossibilitiesComponent {}