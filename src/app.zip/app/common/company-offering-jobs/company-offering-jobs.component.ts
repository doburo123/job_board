import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-company-offering-jobs',
    imports: [RouterLink],
    templateUrl: './company-offering-jobs.component.html',
    styleUrl: './company-offering-jobs.component.scss'
})
export class CompanyOfferingJobsComponent {}